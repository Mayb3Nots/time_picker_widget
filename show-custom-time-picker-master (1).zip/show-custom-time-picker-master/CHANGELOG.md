## 1.0.0+10
- null safety
## 1.0.0+9
- fix readme example path
## 1.0.0+8
- return context on fail validation
## 1.0.0+7
- example folder & changelog file
## 1.0.0+6
- fix demo preview broken link
## 1.0.0+5
- adding demo preview gif
## 1.0.0+4
- sample, online demo & more
## 1.0.0+3
- using only 12hour format
## 0.0.2
- english message & only use 12hourdial
## 0.0.1
- adding a selectableTimePredicate