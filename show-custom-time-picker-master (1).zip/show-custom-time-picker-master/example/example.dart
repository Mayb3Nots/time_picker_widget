import 'package:flutter/material.dart';
import 'package:time_picker_widget/main.dart';

void main() {
  runApp(MyApp());
}
